VELVORA READER APP — PWA PACKAGE

WHAT THIS IS
A separate, reader-only progressive web app. It does not contain the website's Host Studio, admin login, or publishing controls. It reads published books and published chapters from the same Supabase project used by the VELVORA website.

FILES
- index.html: app shell
- styles.css: premium cream/ivory and gold styling + animations
- app.js: reader interface and Supabase public read integration
- manifest.webmanifest: installable app metadata
- sw.js: basic offline shell cache
- icons/: app icons

IMPORTANT CONTENT NOTE
The live app reads rows from Supabase tables `books` and related `chapters`, where books have status='published' and chapters have is_published=true. The supplied website also contains built-in novels in its HTML/local browser storage. Those static/local novels are NOT automatically in Supabase and therefore are not included by this first cloud-connected reader build. Before launch, migrate those legacy novels and their chapters into the same Supabase tables. Once they are in the database and published, the app will display them automatically.

DEPLOYMENT
1. Create a separate folder/repository for this app (do not replace the existing website files).
2. Upload the contents of this folder to a new Vercel project, or deploy it under a dedicated path such as /app/ if your Vercel routing is configured for it.
3. Ensure it is served over HTTPS. Open the deployed URL on Android Chrome and choose Install app / Add to Home screen.
4. Test published books, covers, and chapters using a reader account/device before sharing.
5. For a Play Store Android package (AAB), package the deployed HTTPS PWA as a Trusted Web Activity using Bubblewrap or Android Studio. Configure Digital Asset Links (/.well-known/assetlinks.json) with the release signing certificate. Play Store publishing requires a Google Play developer account and its current registration requirements.

SECURITY
The browser app uses the existing Supabase publishable/anon key. Database Row Level Security must allow public SELECT only for published books and published chapters. Never put a Supabase service-role key or admin credentials in this app.

NOTES
The app is a first functional PWA build, not yet a signed APK/AAB. Validate RLS policies and migrate static novels before public launch. Reader progress/bookmarks are currently stored locally on the reader's device.
